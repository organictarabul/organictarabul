import { initializeApp } from "firebase/app";
import { getAnalytics, isSupported as analyticsIsSupported } from "firebase/analytics";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyDSJnbDzqRW9si6e1DK5VST8YntK5K0O7k",
  authDomain: "organictarabul.firebaseapp.com",
  databaseURL: "https://organictarabul-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "organictarabul",
  storageBucket: "organictarabul.firebasestorage.app",
  messagingSenderId: "1080125000683",
  appId: "1:1080125000683:web:0d97da287f90a826f967ae",
  measurementId: "G-PLQX62QMBX"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getDatabase(app);

export async function initAnalytics() {
  if (typeof window !== "undefined" && await analyticsIsSupported()) {
    return getAnalytics(app);
  }
  return null;
}
