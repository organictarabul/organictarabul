import React, { useEffect, useMemo, useState } from "react";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  reload,
  sendEmailVerification,
  signInWithEmailAndPassword,
  signOut
} from "firebase/auth";
import {
  get,
  onValue,
  push,
  ref as dbRef,
  remove,
  serverTimestamp,
  set,
  update
} from "firebase/database";
import { auth, db } from "./firebase";

const taka = new Intl.NumberFormat("bn-BD", { style: "currency", currency: "BDT", maximumFractionDigits: 0 });
const STATUSES = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"];
const STATUS_BN = {
  pending: "অপেক্ষমাণ",
  confirmed: "কনফার্ম হয়েছে",
  processing: "প্রসেসিং চলছে",
  shipped: "শিপড হয়েছে",
  delivered: "ডেলিভারি সম্পন্ন",
  cancelled: "বাতিল"
};

function asList(value) {
  if (!value) return [];
  return Object.entries(value).map(([id, data]) => ({ id, ...data }));
}

function n(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function slugify(value) {
  return String(value || "product")
    .trim()
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-+|-+$/g, "") || "product";
}

function cleanMobile(value) {
  return String(value || "").replace(/[\s-]/g, "");
}

function validMobile(value) {
  return /^\+?[0-9]{10,15}$/.test(cleanMobile(value));
}

function productPath(product) {
  return `/product/${product.id}/${slugify(product.slug || product.titleBn)}`;
}

function parseRoute() {
  const parts = window.location.pathname.split("/").filter(Boolean);
  if (parts[0] === "product" && parts[1]) return { page: "product", productId: parts[1] };
  if (parts[0] === "admin") return { page: "admin" };
  if (parts[0] === "login") return { page: "login" };
  if (parts[0] === "orders") return { page: "orders" };
  return { page: "home" };
}

function useRouter() {
  const [route, setRoute] = useState(parseRoute());
  useEffect(() => {
    const handle = () => setRoute(parseRoute());
    window.addEventListener("popstate", handle);
    return () => window.removeEventListener("popstate", handle);
  }, []);
  function go(path) {
    window.history.pushState({}, "", path);
    setRoute(parseRoute());
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  return { route, go };
}

function packagesArray(packages) {
  /*
    Convert the packages object (keyed by package_* names) into an array of
    package definitions. Each definition includes a `key` (the package id)
    and normalised `images` array. Older data may store a single `image`
    string instead of an `images` array. We coerce the data so that
    `images` is always an array and provide the deprecated `image` property
    for backward compatibility.
  */
  return Object.entries(packages || {}).map(([key, value]) => {
    let images = [];
    // If the package already has an `images` array, use it
    if (Array.isArray(value.images)) {
      images = value.images.filter(Boolean);
    } else if (typeof value.images === "string" && value.images.trim()) {
      // If `images` is a string (legacy data), split on newlines or commas
      images = value.images
        .split(/\n|,/)
        .map(x => x.trim())
        .filter(Boolean);
    } else if (typeof value.image === "string" && value.image.trim()) {
      // Legacy single-image string or multiple images separated by newline/comma
      images = value.image
        .split(/\n|,/)
        .map(x => x.trim())
        .filter(Boolean);
    }
    return {
      key,
      ...value,
      images,
      image: images[0] || value.image || "",
    };
  });
}

function packagesObject(packages) {
  /*
    Convert the array of package draft objects into the structure stored in
    Firebase. Each package will include `images` (array) and a convenience
    `image` property pointing to the first image. An empty package (missing
    `titleBn`) is skipped. Leading/trailing whitespace is trimmed and
    numerical values are normalised using `n()`.
  */
  const result = {};
  packages.filter(p => p.titleBn).forEach((p, index) => {
    // Convert the images draft (string or array) into an array of URLs
    let imgs = [];
    if (Array.isArray(p.images)) {
      imgs = p.images.map(x => String(x).trim()).filter(Boolean);
    } else if (typeof p.images === "string") {
      // If `images` is a string, split it on newlines or commas to support either separator.
      imgs = p.images
        .split(/\n|,/)
        .map(x => x.trim())
        .filter(Boolean);
    } else if (typeof p.image === "string" && p.image.trim()) {
      // If only the deprecated `image` field is provided, split it on newlines or commas
      // to allow multiple URLs to be entered in a single textarea.  This preserves
      // backward compatibility while enabling multiple images per package.
      imgs = p.image
        .split(/\n|,/)
        .map(x => x.trim())
        .filter(Boolean);
    }
    result[`package_${index + 1}`] = {
      titleBn: p.titleBn.trim(),
      price: n(p.price),
      oldPrice: n(p.oldPrice),
      images: imgs,
      // maintain a deprecated `image` property pointing at the first image for backward compatibility
      image: imgs[0] || "",
      descriptionBn: (p.descriptionBn || "").trim(),
    };
  });
  return result;
}

function embedUrl(url) {
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtu.be")) return `https://www.youtube.com/embed/${u.pathname.replace("/", "")}`;
    if (u.hostname.includes("youtube.com")) {
      const id = u.searchParams.get("v");
      if (id) return `https://www.youtube.com/embed/${id}`;
      if (u.pathname.includes("/shorts/")) return `https://www.youtube.com/embed/${u.pathname.split("/shorts/")[1]}`;
    }
    // Detect Facebook video URLs (including fb.watch) and construct an embed
    // URL using the Facebook video plugin.  According to Meta's developer
    // documentation, videos are embedded via the /plugins/video.php endpoint.
    // We pass the original URL via the href parameter and disable the
    // caption.  The width parameter can be customised; here we use 500 as
    // the default to ensure the iframe renders at a reasonable width.  See
    // https://developers.facebook.com/docs/plugins/video-player/ for details【815064991644239†L56-L64】.
    if (u.hostname.includes("facebook.com") || u.hostname.includes("fb.watch")) {
      // Facebook embed: use the plugins/video.php endpoint without specifying a fixed width.  The
      // iframe will be styled via CSS to maintain its aspect ratio.  According to Meta's
      // documentation, omitting the width allows the plugin to adapt to its container.【815064991644239†L56-L64】
      return `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(url)}&show_text=0`;
    }
  } catch {}
  return url;
}

function whatsApp(settings, productTitle = "") {
  const number = String(settings.whatsappNumber || "8801700000000").replace(/[^0-9]/g, "");
  const base = settings.whatsappText || "আমি Organic Tarabul থেকে পণ্য অর্ডার করতে চাই।";
  return `https://wa.me/${number}?text=${encodeURIComponent(productTitle ? `${base} পণ্য: ${productTitle}` : base)}`;
}

function useStore(isAdmin) {
  const [settings, setSettings] = useState({});
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [admins, setAdmins] = useState([]);

  useEffect(() => {
    const s = onValue(dbRef(db, "settings"), snap => setSettings(snap.val() || {}));
    const c = onValue(dbRef(db, "categories"), snap => setCategories(asList(snap.val())));
    const p = onValue(dbRef(db, "products"), snap => setProducts(asList(snap.val())));
    return () => { s(); c(); p(); };
  }, []);

  useEffect(() => {
    if (!isAdmin) {
      setOrders([]);
      setAdmins([]);
      return undefined;
    }
    const o = onValue(dbRef(db, "orders"), snap => setOrders(asList(snap.val())), err => console.error(err.message));
    const a = onValue(dbRef(db, "admins"), snap => setAdmins(asList(snap.val()).filter(x => x.value !== false)), err => console.error(err.message));
    return () => { o(); a(); };
  }, [isAdmin]);

  return { settings, categories, products, orders, admins };
}

function Header({ settings, user, isAdmin, route, go, logout }) {
  return (
    <header className="topbar">
      <button className="brand" onClick={() => go("/")}>
        <span className="brand-logo">OT</span>
        <span><b>{settings.siteName || "Organic Tarabul"}</b><small>Premium Organic Store</small></span>
      </button>
      <nav>
        <button className={route.page === "home" ? "active" : ""} onClick={() => go("/")}>হোম</button>
        {user && <button className={route.page === "orders" ? "active" : ""} onClick={() => go("/orders")}>আমার অর্ডার</button>}
        {isAdmin && <button className={route.page === "admin" ? "active" : ""} onClick={() => go("/admin")}>Admin</button>}
        {user ? <button onClick={logout}>Logout</button> : <button onClick={() => go("/login")}>Login</button>}
      </nav>
    </header>
  );
}

function Slider({ images = [], alt = "product", small = false }) {
  const list = images.filter(Boolean);
  const [i, setI] = useState(0);
  useEffect(() => {
    if (list.length < 2) return undefined;
    const timer = setInterval(() => setI(x => (x + 1) % list.length), small ? 2500 : 3500);
    return () => clearInterval(timer);
  }, [list.length, small]);
  const src = list[i] || "/placeholder.svg";
  return (
    <div className={small ? "slider small" : "slider"}>
      <img src={src} alt={alt} />
      {list.length > 1 && <>
        <button className="slide prev" onClick={(e) => { e.stopPropagation(); setI(i === 0 ? list.length - 1 : i - 1); }}>‹</button>
        <button className="slide next" onClick={(e) => { e.stopPropagation(); setI((i + 1) % list.length); }}>›</button>
        <div className="dots">{list.map((_, index) => <button key={index} className={index === i ? "on" : ""} onClick={(e) => { e.stopPropagation(); setI(index); }} />)}</div>
      </>}
    </div>
  );
}

function Home({ settings, categories, products, go }) {
  const [category, setCategory] = useState("all");
  const visible = useMemo(() => products
    .filter(p => p.isActive !== false)
    .filter(p => category === "all" || p.categoryId === category)
    .sort((a, b) => n(b.createdAt) - n(a.createdAt)), [products, category]);

  return <>
    <section className="hero">
      <div>
        {/*
          The hero eyebrow text (small tagline above the heading) is configurable via settings.heroEyebrowEn.
          If not provided, fall back to the default English text.
        */}
        <p className="eyebrow">{settings.heroEyebrowEn || "Premium Organic Marketplace"}</p>
        {/*
          Split the hero heading into two separate spans so they don’t overlap.
          The first span displays the site/brand name and the second span shows the hero title.
          Both spans are styled individually in the CSS to appear on separate lines.
        */}
        <h1>
          <span className="hero-site">{settings.siteName || "Organic Tarabul"}</span>
          <span className="hero-title">{settings.heroTitleBn || "খাঁটি অর্গানিক পণ্য এখন ঘরে বসে অর্ডার করুন"}</span>
        </h1>
        {/* The hero subtitle text (below the heading). */}
        <p>{settings.heroSubtitleBn || "প্রিমিয়াম মানের পণ্য, ফ্রি ডেলিভারি এবং সহজ অর্ডার সুবিধা।"}</p>
        <div className="hero-actions">
          {/* Primary call‑to‑action button. Label configurable via settings.heroPrimaryButtonBn. */}
          <button
            className="primary"
            onClick={() => document.getElementById("products")?.scrollIntoView({ behavior: "smooth" })}
          >
            {settings.heroPrimaryButtonBn || "পণ্য দেখুন"}
          </button>
          {/* Secondary call‑to‑action button linking to WhatsApp. Label configurable via settings.heroSecondaryButtonEn. */}
          <a
            className="secondary"
            href={whatsApp(settings)}
            target="_blank"
            rel="noreferrer"
          >
            {settings.heroSecondaryButtonEn || "WhatsApp"}
          </a>
        </div>
      </div>
      {/* Hero card containing a title, description and up to three highlight items. All text is configurable via settings. */}
      <div className="hero-card">
        <b>{settings.heroCardTitleBn || "ফ্রি ডেলিভারি"}</b>
        <p>{settings.heroCardDescriptionBn || "প্রতিটি product card-এ delivery free highlight থাকবে।"}</p>
        {/*
          Render up to three highlight items if provided. If none are provided, fall back to the default list.
        */}
        {settings.heroCardItem1 || settings.heroCardItem2 || settings.heroCardItem3 ? (
          <>
            {settings.heroCardItem1 && <span>{settings.heroCardItem1}</span>}
            {settings.heroCardItem2 && <span>{settings.heroCardItem2}</span>}
            {settings.heroCardItem3 && <span>{settings.heroCardItem3}</span>}
          </>
        ) : (
          <>
            <span>Guest order</span>
            <span>Live order status</span>
            <span>Admin dashboard</span>
          </>
        )}
      </div>
    </section>

    <section className="categories">
      <div className="section-title"><div><p className="eyebrow">Categories</p><h2>ক্যাটাগরি অনুযায়ী পণ্য দেখুন</h2></div></div>
      <div className="category-grid">
        <button className={category === "all" ? "cat active" : "cat"} onClick={() => setCategory("all")}><span>সব</span><b>সব পণ্য</b><small>All products</small></button>
        {categories.map(c => <button key={c.id} className={category === c.id ? "cat active" : "cat"} onClick={() => setCategory(c.id)}><span>{c.image ? <img src={c.image} alt={c.nameBn} /> : (c.nameBn || c.nameEn || "C").slice(0, 1)}</span><b>{c.nameBn || c.nameEn}</b><small>{c.nameEn}</small></button>)}
      </div>
    </section>

    <section id="products" className="section">
      <div className="section-title"><div><p className="eyebrow">Products</p><h2>জনপ্রিয় পণ্যসমূহ</h2></div><strong className="pill">{visible.length} টি পণ্য</strong></div>
      {visible.length ? <div className="product-grid">{visible.map(p => <ProductCard key={p.id} product={p} category={categories.find(c => c.id === p.categoryId)} go={go} />)}</div> : <Empty title="এখনও কোনো পণ্য নেই" text="Admin dashboard থেকে product card তৈরি করুন।" />}
    </section>
  </>;
}

function ProductCard({ product, category, go }) {
  const pkgs = packagesArray(product.packages);
  const price = n(pkgs[0]?.price || product.price);
  return <article className="product-card" onClick={() => go(productPath(product))}>
    <div className="card-img"><Slider images={product.images || []} alt={product.titleBn} small /><span className="delivery">ফ্রি ডেলিভারি</span>{category && <span className="badge">{category.nameBn || category.nameEn}</span>}</div>
    <div className="card-body"><h3>{product.titleBn}</h3><p>{product.shortDescriptionBn}</p><div className="package-tags">{pkgs.slice(0, 3).map(p => <span key={p.key}>{p.titleBn}</span>)}</div><div className="price"><b>{taka.format(price)}</b>{n(product.oldPrice) > 0 && <del>{taka.format(n(product.oldPrice))}</del>}</div><button>অর্ডার করুন</button></div>
  </article>;
}

function ProductPage({ product, category, user, settings, go }) {
  const pkgs = packagesArray(product.packages);
  const fallback = { key: "default", titleBn: "ডিফল্ট প্যাকেজ", price: n(product.price), oldPrice: n(product.oldPrice), image: product.images?.[0] || "", descriptionBn: "" };
  const packageList = pkgs.length ? pkgs : [fallback];
  const [packageKey, setPackageKey] = useState(packageList[0].key);
  const [qty, setQty] = useState(1);
  const [customer, setCustomer] = useState({ name: "", mobile: "", address: "" });
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const selected = packageList.find(p => p.key === packageKey) || packageList[0];
  const total = n(selected.price) * n(qty, 1);
  const campaignLink = `${window.location.origin}${productPath(product)}`;

  useEffect(() => { setPackageKey(packageList[0].key); setMessage(""); setError(""); }, [product.id]);

  async function copyLink() {
    await navigator.clipboard.writeText(campaignLink);
    setMessage("Campaign product link copied.");
    setTimeout(() => setMessage(""), 1600);
  }

  async function order(e) {
    e.preventDefault();
    setError("");
    const mobile = cleanMobile(customer.mobile);
    if (!validMobile(mobile)) { setError("সঠিক মোবাইল নম্বর দিন। ১০ থেকে ১৫ ডিজিট হতে হবে।"); return; }
    const orderRef = push(dbRef(db, "orders"));
    const data = {
      id: orderRef.key,
      productId: product.id,
      productSlug: product.slug || slugify(product.titleBn),
      productTitleBn: product.titleBn,
      packageKey: selected.key,
      packageTitleBn: selected.titleBn,
      packageImage: selected.image || product.images?.[0] || "",
      quantity: n(qty, 1),
      unitPrice: n(selected.price),
      totalPrice: total,
      deliveryCharge: 0,
      currency: "BDT",
      customer: { name: customer.name.trim(), mobile, address: customer.address.trim(), uid: user?.uid || "", email: user?.email || "" },
      status: "pending",
      createdAt: serverTimestamp()
    };
    try {
      setBusy(true);
      const updates = { [`orders/${orderRef.key}`]: data };
      if (user?.uid) updates[`userOrders/${user.uid}/${orderRef.key}`] = true;
      await update(dbRef(db), updates);
      setMessage(`অর্ডার সফল হয়েছে। Order ID: ${orderRef.key}`);
      setCustomer({ name: "", mobile: "", address: "" });
      setQty(1);
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  return <section className="product-page">
    <button className="ghost" onClick={() => go("/")}>← হোমে ফিরে যান</button>
    <div className="detail-grid">
      <div>
        <Slider images={product.images || []} alt={product.titleBn} />
        {product.videoLinks?.length > 0 && (
          <div className="media">
            <h3>ভিডিও</h3>
            {product.videoLinks.map((v, idx) => {
              /*
                Determine the orientation of the video based on the URL.  Portrait videos
                (such as Facebook reels) typically contain keywords like "reel" or
                "vertical" in the URL.  For portrait content we use a 4:5 ratio; for
                landscape content we use a 2:1 ratio.  These defaults follow
                Meta's recommended aspect ratios for feed and reel placements【738779426582201†L61-L69】.

                Each product can specify per-video zoom and max width values via the
                `videoZooms` and `videoMaxWidths` arrays.  The admin enters one value per
                line in the product editor; these values correspond by index to the
                entries in `videoLinks`.  Zoom values are interpreted as percentages of
                the wrapper width (e.g. "80" yields an iframe width of 80% within its
                wrapper), allowing the video size to change independently of the frame.
                Max width values are pixel limits for the wrapper itself.  When no
                values are provided, defaults of 100% width and auto max width are used.
              */
              const isVertical = /reel|vertical/i.test(v);
              const ratio = isVertical ? "4 / 5" : "2 / 1";
              // Determine per-video max width from product.videoMaxWidths array
              let maxW;
              if (Array.isArray(product.videoMaxWidths) && product.videoMaxWidths[idx] != null) {
                const parsed = parseFloat(product.videoMaxWidths[idx]);
                if (Number.isFinite(parsed) && parsed > 0) maxW = parsed;
              }
              // Determine per-video zoom percentage (interpreted as width percentage of wrapper)
              let zoomPercent;
              if (Array.isArray(product.videoZooms) && product.videoZooms[idx] != null) {
                const z = parseFloat(product.videoZooms[idx]);
                if (Number.isFinite(z) && z > 0) zoomPercent = z;
              }
              // Wrapper style controls the frame (max width and centering)
              const wrapperStyle = {
                width: "100%",
                marginLeft: "auto",
                marginRight: "auto",
              };
              if (maxW) {
                wrapperStyle.maxWidth = `${maxW}px`;
              }
              // Iframe style controls the actual video dimensions; aspect ratio ensures height
              const iframeStyle = {
                aspectRatio: ratio,
                width: zoomPercent ? `${zoomPercent}%` : "100%",
                height: "auto",
                display: "block",
                marginLeft: "auto",
                marginRight: "auto",
              };
              return (
                <div key={v} style={wrapperStyle}>
                  <iframe
                    src={embedUrl(v)}
                    title="video"
                    allowFullScreen
                    style={iframeStyle}
                  />
                </div>
              );
            })}
          </div>
        )}
      </div>
      <div className="detail-card"><div className="detail-top"><p className="eyebrow">{category?.nameBn || "Product"}</p><button className="secondary" onClick={copyLink}>Campaign Link Copy</button></div><h1>{product.titleBn}</h1><p>{product.shortDescriptionBn}</p><div className="free-box"><b>ফ্রি ডেলিভারি</b><span>ডেলিভারি চার্জ ০ টাকা</span></div><h3>বিবরণ</h3><p className="desc">{product.descriptionBn}</p>{product.benefitsBn?.length > 0 && <ul>{product.benefitsBn.map(x => <li key={x}>{x}</li>)}</ul>}
        <h2>প্যাকেজ নির্বাচন করুন</h2>
        <div className="package-cards">
          {packageList.map(p => (
            <button
              key={p.key}
              className={packageKey === p.key ? "pkg selected" : "pkg"}
              onClick={() => setPackageKey(p.key)}
            >
              {/* Show all package images together.  Use the provided `images` array if
                  available; otherwise fall back to a single `image` or the
                  product's first image. */}
              <div className="pkg-images">
                {(Array.isArray(p.images) && p.images.length > 0 ? p.images : [p.image || product.images?.[0] || "/placeholder.svg"])
                  .map((imgSrc, idx) => (
                    <img key={idx} src={imgSrc} alt={p.titleBn} />
                  ))}
              </div>
              <span>
                <b>{p.titleBn}</b>
                <small>{p.descriptionBn || "বিশেষ প্যাকেজ"}</small>
                <strong>{taka.format(n(p.price))}</strong>
                {n(p.oldPrice) > 0 && <del>{taka.format(n(p.oldPrice))}</del>}
              </span>
            </button>
          ))}
        </div>
        <form className="order-form" onSubmit={order}>
          <h2>অর্ডার ফর্ম</h2>
          {/* Quantity selector with – and + buttons */}
          <label>পরিমাণ
            <div className="qty-control">
              <button
                type="button"
                className="qty-btn"
                onClick={() => setQty(q => Math.max(1, q - 1))}
              >−</button>
              <input
                type="number"
                min="1"
                value={qty}
                onChange={e => setQty(Math.max(1, n(e.target.value, 1)))}
              />
              <button
                type="button"
                className="qty-btn"
                onClick={() => setQty(q => q + 1)}
              >+</button>
            </div>
          </label>
          <label>নাম <small>optional</small><input value={customer.name} onChange={e => setCustomer({ ...customer, name: e.target.value })} /></label>
          <label>মোবাইল নম্বর *<input required value={customer.mobile} onChange={e => setCustomer({ ...customer, mobile: e.target.value })} placeholder="01XXXXXXXXX" /></label>
          <label>ঠিকানা <small>optional</small><textarea value={customer.address} onChange={e => setCustomer({ ...customer, address: e.target.value })} /></label>
          <div className="summary">
            <b>Order Summary</b>
            <span>{product.titleBn}</span>
            <span>{selected.titleBn}</span>
            <span>ডেলিভারি: ফ্রি</span>
            <strong>মোট: {taka.format(total)}</strong>
          </div>
          {error && <p className="error">{error}</p>}
          <button className="primary full" disabled={busy}>{busy ? "সাবমিট হচ্ছে..." : "অর্ডার সাবমিট করুন"}</button>
        </form>
        {message && <p className="success">{message}</p>}
        <a className="whatsapp-inline" href={whatsApp(settings, product.titleBn)} target="_blank" rel="noreferrer">WhatsApp-এ কথা বলুন</a>
      </div>
    </div>
  </section>;
}

function AuthPage({ user, go }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ email: "", password: "" });
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  useEffect(() => { if (user?.emailVerified) go("/"); }, [user?.emailVerified]);
  async function submit(e) {
    e.preventDefault(); setMsg(""); setErr("");
    try {
      if (mode === "register") {
        const c = await createUserWithEmailAndPassword(auth, form.email, form.password);
        await sendEmailVerification(c.user);
        await set(dbRef(db, `users/${c.user.uid}`), { email: c.user.email, emailVerified: false, createdAt: serverTimestamp() });
        setMsg("Registration successful. Email verify করে login করুন।");
      } else {
        const c = await signInWithEmailAndPassword(auth, form.email, form.password);
        await reload(c.user);
        await update(dbRef(db, `users/${c.user.uid}`), { email: c.user.email, emailVerified: c.user.emailVerified, lastLoginAt: serverTimestamp() });
        if (c.user.emailVerified) go("/"); else setMsg("Email verified নয়। Inbox থেকে verify করে আবার login করুন।");
      }
    } catch (e2) { setErr(e2.message); }
  }
  async function resend() { if (auth.currentUser) { await sendEmailVerification(auth.currentUser); setMsg("Verification email আবার পাঠানো হয়েছে।"); } }
  return <section className="auth-card"><h1>{mode === "login" ? "Login" : "Register"}</h1><p>Verified login হলে home page-এ redirect হবে।</p><form onSubmit={submit}><label>Email<input type="email" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></label><label>Password<input type="password" minLength="6" required value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} /></label><button className="primary full">{mode === "login" ? "Login" : "Register"}</button></form><button className="link" onClick={() => setMode(mode === "login" ? "register" : "login")}>{mode === "login" ? "নতুন account খুলুন" : "Login করুন"}</button>{auth.currentUser && !auth.currentUser.emailVerified && <button className="secondary" onClick={resend}>Verification email resend</button>}{msg && <p className="success">{msg}</p>}{err && <p className="error">{err}</p>}</section>;
}

function CustomerOrders({ user, go }) {
  const [ids, setIds] = useState([]);
  const [orders, setOrders] = useState([]);
  useEffect(() => {
    if (!user) return undefined;
    const unsub = onValue(dbRef(db, `userOrders/${user.uid}`), snap => setIds(Object.keys(snap.val() || {})));
    return () => unsub();
  }, [user?.uid]);
  useEffect(() => {
    if (!user || !ids.length) { setOrders([]); return undefined; }
    const unsubs = ids.map(id => onValue(dbRef(db, `orders/${id}`), snap => {
      const val = snap.val();
      setOrders(old => val ? [...old.filter(o => o.id !== id), val].sort((a, b) => n(b.createdAt) - n(a.createdAt)) : old.filter(o => o.id !== id));
    }));
    return () => unsubs.forEach(u => u());
  }, [user?.uid, ids.join("|")]);
  if (!user) return <Empty title="Login required" text="নিজের order status দেখতে login করুন।" action="Login" onAction={() => go("/login")} />;
  return <section className="section"><div className="section-title"><div><p className="eyebrow">Customer Account</p><h1>আমার অর্ডার স্ট্যাটাস</h1></div></div>{orders.length ? <div className="customer-orders">{orders.map(o => <article key={o.id} className="customer-order"><img src={o.packageImage || "/placeholder.svg"} alt={o.productTitleBn} /><div><h3>{o.productTitleBn}</h3><p>{o.packageTitleBn}</p><p>{taka.format(n(o.totalPrice))}</p><span className={`status ${o.status}`}>{STATUS_BN[o.status] || o.status}</span></div></article>)}</div> : <Empty title="এখনও কোনো registered order নেই" text="Login অবস্থায় order করলে এখানে status দেখা যাবে।" />}</section>;
}

function AdminPage({ user, isAdmin, settings, categories, products, orders, admins, go }) {
  const [tab, setTab] = useState("products");
  if (!user) return <Empty title="Login required" text="Admin panel দেখতে login করুন।" action="Login" onAction={() => go("/login")} />;
  if (!user.emailVerified) return <Empty title="Email verification required" text="Admin panel ব্যবহার করতে email verified হতে হবে।" />;
  if (!isAdmin) return <Empty title="Admin access নেই" text={`Realtime Database-এ admins/${user.uid}: true যোগ করুন।`} />;
  return <section className="admin"><div className="section-title"><div><p className="eyebrow">Admin Dashboard</p><h1>Professional Store Control</h1></div><div className="tabs">{["products", "categories", "orders", "settings", "admins"].map(x => <button key={x} className={tab === x ? "active" : ""} onClick={() => setTab(x)}>{x}</button>)}</div></div>{tab === "products" && <ProductAdmin products={products} categories={categories} />}{tab === "categories" && <CategoryAdmin categories={categories} />}{tab === "orders" && <OrdersAdmin orders={orders} />}{tab === "settings" && <SettingsAdmin settings={settings} />}{tab === "admins" && <AdminsAdmin admins={admins} currentUid={user.uid} />}</section>;
}

function SettingsAdmin({ settings }) {
  const [f, setF] = useState(settings || {});
  const [msg, setMsg] = useState("");
  useEffect(() => setF(settings || {}), [JSON.stringify(settings)]);
  async function save(e) {
    e.preventDefault();
    /*
      Persist the settings. Developer name is not editable from the admin panel, so we exclude
      it from the update payload. The existing developerName value stored in settings will be retained.
    */
    const {
      developerName,
      videoLandscapeRatio,
      videoPortraitRatio,
      videoMaxWidth,
      videoZoom,
      ...rest
    } = f;
    await update(dbRef(db, "settings"), {
      ...rest,
      siteName: f.siteName || "Organic Tarabul",
      updatedAt: serverTimestamp()
    });
    setMsg("Settings updated.");
  }
  return (
    <form className="admin-card form" onSubmit={save}>
      <h2>Website, WhatsApp & Footer Edit</h2>
      <div className="three">
        <label>Website Name
          <input value={f.siteName || ""} onChange={e => setF({ ...f, siteName: e.target.value })} />
        </label>
        <label>WhatsApp Number
          <input value={f.whatsappNumber || ""} onChange={e => setF({ ...f, whatsappNumber: e.target.value })} />
        </label>
        <label>Developer Name
          <input value={f.developerName || "Dual School And College"} disabled />
        </label>
      </div>
      {/* Hero section settings */}
      <label>Hero Eyebrow (English)
        <input
          value={f.heroEyebrowEn || ""}
          onChange={e => setF({ ...f, heroEyebrowEn: e.target.value })}
        />
      </label>
      <label>Hero Title (Bangla)
        <input
          value={f.heroTitleBn || ""}
          onChange={e => setF({ ...f, heroTitleBn: e.target.value })}
        />
      </label>
      <label>Hero Subtitle (Bangla)
        <textarea
          value={f.heroSubtitleBn || ""}
          onChange={e => setF({ ...f, heroSubtitleBn: e.target.value })}
        ></textarea>
      </label>
      <label>Hero Primary Button Label (Bangla)
        <input
          value={f.heroPrimaryButtonBn || ""}
          onChange={e => setF({ ...f, heroPrimaryButtonBn: e.target.value })}
        />
      </label>
      <label>Hero Secondary Button Label
        <input
          value={f.heroSecondaryButtonEn || ""}
          onChange={e => setF({ ...f, heroSecondaryButtonEn: e.target.value })}
        />
      </label>
      <label>Hero Card Title (Bangla)
        <input
          value={f.heroCardTitleBn || ""}
          onChange={e => setF({ ...f, heroCardTitleBn: e.target.value })}
        />
      </label>
      <label>Hero Card Description (Bangla)
        <textarea
          value={f.heroCardDescriptionBn || ""}
          onChange={e => setF({ ...f, heroCardDescriptionBn: e.target.value })}
        ></textarea>
      </label>
      <div className="three">
        <label>Hero Card Item 1
          <input
            value={f.heroCardItem1 || ""}
            onChange={e => setF({ ...f, heroCardItem1: e.target.value })}
          />
        </label>
        <label>Hero Card Item 2
          <input
            value={f.heroCardItem2 || ""}
            onChange={e => setF({ ...f, heroCardItem2: e.target.value })}
          />
        </label>
        <label>Hero Card Item 3
          <input
            value={f.heroCardItem3 || ""}
            onChange={e => setF({ ...f, heroCardItem3: e.target.value })}
          />
        </label>
      </div>
      <label>WhatsApp Message
        <textarea value={f.whatsappText || ""} onChange={e => setF({ ...f, whatsappText: e.target.value })}></textarea>
      </label>

      <label>Footer Title
        <input value={f.footerTitleBn || ""} onChange={e => setF({ ...f, footerTitleBn: e.target.value })} />
      </label>
      <label>Footer Description
        <textarea value={f.footerDescriptionBn || ""} onChange={e => setF({ ...f, footerDescriptionBn: e.target.value })}></textarea>
      </label>
      <div className="three">
        <label>Phone
          <input value={f.footerPhone || ""} onChange={e => setF({ ...f, footerPhone: e.target.value })} />
        </label>
        <label>Email
          <input value={f.footerEmail || ""} onChange={e => setF({ ...f, footerEmail: e.target.value })} />
        </label>
        <label>Address
          <input value={f.footerAddress || ""} onChange={e => setF({ ...f, footerAddress: e.target.value })} />
        </label>
      </div>
      <button className="primary">Save</button>
      {msg && <p className="success">{msg}</p>}
    </form>
  );
}

function CategoryAdmin({ categories }) {
  const empty = { nameBn: "", nameEn: "", image: "" };
  const [f, setF] = useState(empty); const [edit, setEdit] = useState("");
  function load(c) { setEdit(c.id); setF({ nameBn: c.nameBn || "", nameEn: c.nameEn || "", image: c.image || "" }); }
  async function save(e) { e.preventDefault(); const id = edit || push(dbRef(db, "categories")).key; await set(dbRef(db, `categories/${id}`), { id, nameBn: f.nameBn, nameEn: f.nameEn, image: f.image, slug: slugify(f.nameEn || f.nameBn), createdAt: categories.find(c => c.id === id)?.createdAt || serverTimestamp(), updatedAt: serverTimestamp() }); setF(empty); setEdit(""); }
  async function del(id) { if (confirm("Delete category?")) await remove(dbRef(db, `categories/${id}`)); }
  return <div className="admin-grid"><form className="admin-card form" onSubmit={save}><h2>{edit ? "Edit Category" : "Create Category"}</h2><label>বাংলা নাম<input required value={f.nameBn} onChange={e => setF({ ...f, nameBn: e.target.value })} /></label><label>English<input value={f.nameEn} onChange={e => setF({ ...f, nameEn: e.target.value })} /></label><label>Image URL<input value={f.image} onChange={e => setF({ ...f, image: e.target.value })} /></label><button className="primary">{edit ? "Update" : "Save"}</button>{edit && <button type="button" className="secondary" onClick={() => { setEdit(""); setF(empty); }}>Cancel</button>}</form><div className="admin-card"><h2>Categories</h2>{categories.map(c => <div className="row" key={c.id}><span>{c.nameBn || c.nameEn}</span><div><button className="secondary" onClick={() => load(c)}>Edit</button><button className="danger" onClick={() => del(c.id)}>Delete</button></div></div>)}</div></div>;
}

function ProductAdmin({ products, categories }) {
  const empty = {
    titleBn: "",
    categoryId: "",
    shortDescriptionBn: "",
    descriptionBn: "",
    benefitsBn: "",
    price: "",
    oldPrice: "",
    stock: "",
    imageLinks: "",
    videoLinks: "",
    videoZooms: "",
    videoMaxWidths: "",
    isActive: true,
  };
  const [f, setF] = useState(empty);
  // Each package draft includes an `image` field which may contain one or more URLs separated by commas or new lines.
  const [pkgs, setPkgs] = useState([
    {
      titleBn: "৫০০ গ্রাম",
      price: "",
      oldPrice: "",
      image: "",
      descriptionBn: "",
    },
  ]);
  const [edit, setEdit] = useState("");
  function clear() {
    setF(empty);
    setPkgs([
      {
        titleBn: "৫০০ গ্রাম",
        price: "",
        oldPrice: "",
        image: "",
        descriptionBn: "",
      },
    ]);
    setEdit("");
  }
  function load(p) {
    setEdit(p.id);
    setF({
      titleBn: p.titleBn || "",
      categoryId: p.categoryId || "",
      shortDescriptionBn: p.shortDescriptionBn || "",
      descriptionBn: p.descriptionBn || "",
      benefitsBn: (p.benefitsBn || []).join("\n"),
      price: p.price || "",
      oldPrice: p.oldPrice || "",
      stock: p.stock || "",
      imageLinks: (p.images || []).join("\n"),
      videoLinks: (p.videoLinks || []).join("\n"),
      videoZooms: (p.videoZooms || []).join("\n"),
      videoMaxWidths: (p.videoMaxWidths || []).join("\n"),
      isActive: p.isActive !== false,
    });
    // Convert the packages stored in Firebase into draft objects for editing.
    const arr = packagesArray(p.packages);
    if (arr.length) {
      setPkgs(
        arr.map(pkg => ({
          titleBn: pkg.titleBn || "",
          price: pkg.price || "",
          oldPrice: pkg.oldPrice || "",
          // store all images in a newline separated string in the `image` field for editing
          image: (pkg.images || []).join("\n"),
          descriptionBn: pkg.descriptionBn || "",
        }))
      );
    } else {
      setPkgs([
        {
          titleBn: "৫০০ গ্রাম",
          price: p.price || "",
          oldPrice: "",
          image: (p.images || []).slice(0, 1).join("\n"),
          descriptionBn: "",
        },
      ]);
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function pkg(i, key, value) { setPkgs(old => old.map((p, index) => index === i ? { ...p, [key]: value } : p)); }
  async function save(e) {
    e.preventDefault();
    // Determine the product ID. If editing an existing product use its id; otherwise generate a new key.
    const id = edit || push(dbRef(db, "products")).key;
    const existing = products.find(p => p.id === id);
    // Parse image, video, zoom and width inputs into arrays.  Each line represents one entry.
    const imageArray = (f.imageLinks || "").split("\n").map(x => x.trim()).filter(Boolean);
    const videoArray = (f.videoLinks || "").split("\n").map(x => x.trim()).filter(Boolean);
    const zoomArray = (f.videoZooms || "").split("\n").map(x => x.trim()).filter(Boolean);
    const widthArray = (f.videoMaxWidths || "").split("\n").map(x => x.trim()).filter(Boolean);
    // Persist the product to Firebase.  Include per-video zooms and max widths for fine-grained control.
    await set(dbRef(db, `products/${id}`), {
      id,
      slug: slugify(f.titleBn),
      titleBn: f.titleBn,
      categoryId: f.categoryId,
      shortDescriptionBn: f.shortDescriptionBn,
      descriptionBn: f.descriptionBn,
      benefitsBn: f.benefitsBn.split("\n").map(x => x.trim()).filter(Boolean),
      price: n(f.price),
      oldPrice: n(f.oldPrice),
      stock: n(f.stock),
      images: imageArray,
      videoLinks: videoArray,
      // Store per-video zooms and widths.  These arrays may be shorter or longer
      // than the videoLinks array; the ProductPage will handle missing values.
      videoZooms: zoomArray,
      videoMaxWidths: widthArray,
      videoUrls: [],
      packages: packagesObject(pkgs),
      isActive: !!f.isActive,
      createdAt: existing?.createdAt || serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    clear();
  }
  async function del(id) { if (confirm("Delete product?")) await remove(dbRef(db, `products/${id}`)); }
  return <div className="admin-grid wide"><form className="admin-card form" onSubmit={save}><h2>{edit ? "Edit Product" : "Create Product"}</h2><label>বাংলা নাম<input required value={f.titleBn} onChange={e => setF({ ...f, titleBn: e.target.value })} /></label><label>Category<select required value={f.categoryId} onChange={e => setF({ ...f, categoryId: e.target.value })}><option value="">Select</option>{categories.map(c => <option key={c.id} value={c.id}>{c.nameBn || c.nameEn}</option>)}</select></label><label>Short Description<textarea required value={f.shortDescriptionBn} onChange={e => setF({ ...f, shortDescriptionBn: e.target.value })} /></label><label>Full Description<textarea required value={f.descriptionBn} onChange={e => setF({ ...f, descriptionBn: e.target.value })} /></label><label>Benefits one per line<textarea value={f.benefitsBn} onChange={e => setF({ ...f, benefitsBn: e.target.value })} /></label><div className="three"><label>Price<input type="number" required value={f.price} onChange={e => setF({ ...f, price: e.target.value })} /></label><label>Old Price<input type="number" value={f.oldPrice} onChange={e => setF({ ...f, oldPrice: e.target.value })} /></label><label>Stock<input type="number" value={f.stock} onChange={e => setF({ ...f, stock: e.target.value })} /></label></div><label className="check"><input type="checkbox" checked={f.isActive} onChange={e => setF({ ...f, isActive: e.target.checked })} /> Visible</label><div className="package-editor"><div className="between"><h3>Packages with image</h3><button type="button" className="secondary" onClick={() => setPkgs([...pkgs, { titleBn: "", price: "", oldPrice: "", image: "", descriptionBn: "" }])}>+ Add</button></div>{pkgs.map((p, i) => <div className="pkg-edit" key={i}><input placeholder="Package" value={p.titleBn} onChange={e => pkg(i, "titleBn", e.target.value)} /><input placeholder="Price" type="number" value={p.price} onChange={e => pkg(i, "price", e.target.value)} /><input placeholder="Old" type="number" value={p.oldPrice || ""} onChange={e => pkg(i, "oldPrice", e.target.value)} /><input placeholder="Package image URLs (comma or newline separated)" value={p.image || ""} onChange={e => pkg(i, "image", e.target.value)} /><input placeholder="Note" value={p.descriptionBn || ""} onChange={e => pkg(i, "descriptionBn", e.target.value)} />{pkgs.length > 1 && <button type="button" className="danger" onClick={() => setPkgs(pkgs.filter((_, x) => x !== i))}>×</button>}</div>)}</div><label>Product Image URLs, one per line<textarea value={f.imageLinks} onChange={e => setF({ ...f, imageLinks: e.target.value })} /></label><label>YouTube/video links, one per line<textarea value={f.videoLinks} onChange={e => setF({ ...f, videoLinks: e.target.value })} /></label><label>Video zooms (%) – one per line<textarea value={f.videoZooms} onChange={e => setF({ ...f, videoZooms: e.target.value })} /></label><label>Video max widths (px) – one per line<textarea value={f.videoMaxWidths} onChange={e => setF({ ...f, videoMaxWidths: e.target.value })} /></label><button className="primary">{edit ? "Update Product" : "Create Product"}</button>{edit && <button type="button" className="secondary" onClick={clear}>Cancel</button>}</form><div className="admin-card"><h2>Products</h2>{products.map(p => <div className="row product-row" key={p.id}><span><b>{p.titleBn}</b><small>{productPath(p)}</small></span><div><button className="secondary" onClick={() => load(p)}>Edit</button><button className="danger" onClick={() => del(p.id)}>Delete</button></div></div>)}</div></div>;
}

function OrdersAdmin({ orders }) {
  const sorted = [...orders].sort((a, b) => n(b.createdAt) - n(a.createdAt));
  async function setStatus(id, status) { await update(dbRef(db, `orders/${id}`), { status, updatedAt: serverTimestamp() }); }
  async function del(id) { if (confirm("Delete order?")) await remove(dbRef(db, `orders/${id}`)); }
  return <div className="admin-card"><h2>Customer Orders</h2>{sorted.length ? <div className="orders">{sorted.map(o => <article className="order" key={o.id}><div><b>{o.productTitleBn}</b><span>{o.packageTitleBn}</span><span>{taka.format(n(o.totalPrice))}</span><span>Delivery: Free</span></div><div><b>Customer</b><span>{o.customer?.name || "No name"}</span><span>{o.customer?.mobile}</span><span>{o.customer?.address || "No address"}</span><span>{o.customer?.email || "Guest"}</span></div><div><select value={o.status || "pending"} onChange={e => setStatus(o.id, e.target.value)}>{STATUSES.map(s => <option key={s} value={s}>{s}</option>)}</select><button className="danger" onClick={() => del(o.id)}>Delete</button></div></article>)}</div> : <Empty title="No orders yet" text="Customer order submit করলে এখানে দেখা যাবে।" />}</div>;
}

function AdminsAdmin({ admins, currentUid }) {
  const [uid, setUid] = useState("");
  async function add(e) { e.preventDefault(); if (uid.trim()) { await set(dbRef(db, `admins/${uid.trim()}`), true); setUid(""); } }
  async function del(id) { if (id === currentUid) return alert("নিজের admin access নিজে remove করবেন না।"); if (confirm("Remove admin?")) await remove(dbRef(db, `admins/${id}`)); }
  return <div className="admin-grid"><form className="admin-card form" onSubmit={add}><h2>Add More Admin</h2><p>Firebase Authentication থেকে User UID copy করে দিন। Email দিলে কাজ করবে না।</p><label>User UID<input value={uid} onChange={e => setUid(e.target.value)} /></label><button className="primary">Add Admin</button></form><div className="admin-card"><h2>Admin List</h2>{admins.map(a => <div className="row" key={a.id}><span>{a.id}</span><button className="danger" onClick={() => del(a.id)}>Remove</button></div>)}</div></div>;
}

function Footer({ settings, categories, go }) {
  return <footer className="footer"><div className="footer-grid"><div><h2>{settings.footerTitleBn || settings.siteName || "Organic Tarabul"}</h2><p>{settings.footerDescriptionBn || "খাঁটি ও বিশ্বস্ত পণ্যের বাংলা ই-কমার্স প্ল্যাটফর্ম।"}</p><b>Developed by {settings.developerName || "Dual School And College"}</b></div><div><h3>Categories</h3>{categories.slice(0, 6).map(c => <button key={c.id} onClick={() => go("/")}>{c.nameBn || c.nameEn}</button>)}</div><div><h3>Contact</h3><span>{settings.footerPhone || "Phone update করুন"}</span><span>{settings.footerEmail || "Email update করুন"}</span><span>{settings.footerAddress || "Address update করুন"}</span></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} {settings.siteName || "Organic Tarabul"}</span><span>Free delivery campaign ready</span></div></footer>;
}

function Empty({ title, text, action, onAction }) {
  return <div className="empty"><h2>{title}</h2><p>{text}</p>{action && <button className="primary" onClick={onAction}>{action}</button>}</div>;
}

export default function App() {
  const { route, go } = useRouter();
  const [user, setUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const { settings, categories, products, orders, admins } = useStore(isAdmin);

  useEffect(() => onAuthStateChanged(auth, async current => {
    setUser(current);
    if (!current) { setIsAdmin(false); return; }
    const snap = await get(dbRef(db, `admins/${current.uid}`));
    setIsAdmin(snap.val() === true);
  }), []);

  async function logout() { await signOut(auth); setIsAdmin(false); go("/"); }

  const selectedProduct = products.find(p => p.id === route.productId);
  const selectedCategory = selectedProduct ? categories.find(c => c.id === selectedProduct.categoryId) : null;

  return (
    <div>
      <Header settings={settings} user={user} isAdmin={isAdmin} route={route} go={go} logout={logout} />
      <main className="container">
        {route.page === "home" && <Home settings={settings} categories={categories} products={products} go={go} />}
        {route.page === "product" && selectedProduct && (
          <ProductPage
            product={selectedProduct}
            category={selectedCategory}
            user={user}
            settings={settings}
            go={go}
          />
        )}
        {route.page === "product" && !selectedProduct && (
          <Empty
            title="Product পাওয়া যায়নি"
            text="হোমে ফিরে অন্য product দেখুন।"
            action="হোম"
            onAction={() => go("/")}
          />
        )}
        {route.page === "login" && <AuthPage user={user} go={go} />}
        {route.page === "orders" && <CustomerOrders user={user} go={go} />}
        {route.page === "admin" && (
          <AdminPage
            user={user}
            isAdmin={isAdmin}
            settings={settings}
            categories={categories}
            products={products}
            orders={orders}
            admins={admins}
            go={go}
          />
        )}
      </main>
      {/* Floating WhatsApp button with official icon */}
      <a className="whatsapp" href={whatsApp(settings)} target="_blank" rel="noreferrer">
        <img src="/whatsapp.svg" alt="WhatsApp" />
      </a>
      <Footer settings={settings} categories={categories} go={go} />
    </div>
  );
}
